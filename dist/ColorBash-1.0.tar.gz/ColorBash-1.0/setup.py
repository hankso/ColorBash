from distutils.core import setup

setup(name = 'ColorBash',
      version = '1.0',
      description = 'Make your output in bash colorful',
      author = 'Hankso',
      author_email = '3080863354@qq.com',
      license = 'GPL',
      package_dir = {'colorbash':'src'},
      packages = ['colorbash'],
#==============================================================================
#       package_data = {},
#       data_files = [(),],
#==============================================================================
#==============================================================================
#       requires = [],
#       provides = [],
#==============================================================================
)
